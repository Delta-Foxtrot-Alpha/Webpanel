--[[
	The Adonis API provides useful information on Adonis, its functions, and more.
	You can find the current documentation below:
	https://github.com/Sceleratis/Adonis/wiki

--]]
