while true do
  script.Parent.Texture = "http://www.roblox.com/asset/?id=183747849"
  wait(0.05)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=183747854"
  wait(0.05)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=183747863"
  wait(0.05)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=183747870"
  wait(0.05)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=183747877"
  wait(0.05)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=183747879"
  wait(0.05)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=183747885"
  wait(0.05)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=183747890"
  wait(0.05)
end